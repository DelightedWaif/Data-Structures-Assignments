template<class T>
class node;

template<class T>
class node{
  public:
    node<T>* next = nullptr;
    int count=0;
    T funStuff;
};
